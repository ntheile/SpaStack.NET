﻿define([], function() {
    return {
        apiUrl: "" // "" for prod or "http://spastack.azurewebsites.net" for phonegap
    };
});
