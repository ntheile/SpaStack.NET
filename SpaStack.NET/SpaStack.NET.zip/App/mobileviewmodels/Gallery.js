﻿define(['services/dbmobile'], function(db){
    return {
        data: db.gallery
    };
});
